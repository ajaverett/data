#### ASL STATUS ####

xmdlasl = lmer(SubjListZ ~ ASLstat + (1 | SubjID) + (1 | EntryID), data = ASLLEXR)
summary(xmdlasl)
Linear mixed model fit by REML. t-tests use Satterthwaite's method ['lmerModLmerTest']
Formula: SubjListZ ~ ASLstat + (1 | SubjID) + (1 | EntryID)
   Data: ASLLEXR

REML criterion at convergence: 178390.6

Scaled residuals: 
    Min      1Q  Median      3Q     Max 
-6.0689 -0.6487  0.0065  0.6704  4.7239 

Random effects:
 Groups   Name        Variance  Std.Dev.
 EntryID  (Intercept) 0.4095603 0.63997 
 SubjID   (Intercept) 0.0003038 0.01743 
 Residual             0.5653276 0.75188 
Number of obs: 75038, groups:  EntryID, 2723; SubjID, 129

Fixed effects:
                   Estimate Std. Error         df t value Pr(>|t|)    
(Intercept)      -5.163e-02  1.319e-02  2.005e+03  -3.915 9.36e-05 ***
ASLstatnonnative  8.286e-03  6.776e-03  1.107e+02   1.223    0.224    
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Correlation of Fixed Effects:
            (Intr)
ASLsttnnntv -0.26




#### FREQ ~ AGE + ASLSTAT + YOED ####

xmdlasl = lmer(SubjListZ ~ ASLstat + Age + YoEd + (1 | SubjID) + (1 | EntryID), data = ASLLEXR)
summary(xmdlasl)
Linear mixed model fit by REML. t-tests use Satterthwaite's method ['lmerModLmerTest']
Formula: SubjListZ ~ ASLstat + Age + YoEd + (1 | SubjID) + (1 | EntryID)
   Data: ASLLEXR

REML criterion at convergence: 175949

Scaled residuals: 
    Min      1Q  Median      3Q     Max 
-6.0733 -0.6496  0.0053  0.6707  4.7220 

Random effects:
 Groups   Name        Variance  Std.Dev.
 EntryID  (Intercept) 0.4087543 0.63934 
 SubjID   (Intercept) 0.0002989 0.01729 
 Residual             0.5658634 0.75224 
Number of obs: 73943, groups:  EntryID, 2723; SubjID, 125

Fixed effects:
                   Estimate Std. Error         df t value Pr(>|t|)   
(Intercept)      -8.693e-02  3.042e-02  1.323e+02  -2.858  0.00495 **
ASLstatnonnative  7.255e-03  7.056e-03  9.957e+01   1.028  0.30630   
Age               3.095e-04  3.071e-04  9.738e+01   1.008  0.31600   
YoEd              1.316e-03  1.399e-03  8.449e+01   0.941  0.34957   
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Correlation of Fixed Effects:
            (Intr) ASLstt Age   
ASLsttnnntv  0.019              
Age         -0.392 -0.252       
YoEd        -0.830 -0.052  0.050
